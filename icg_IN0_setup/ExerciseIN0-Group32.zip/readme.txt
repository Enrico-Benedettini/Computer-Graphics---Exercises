Task IN0.1: Set your background color - simply followed the guided steps and picked yellow as background color, no problem following the guide
Task IN0.2: Modify the scene - again, followed the guided steps and set the color of the new material to a darker green so that I could see the difference from the previous.
Task IN0.3:Custom mesh - followed again the steps though we don't really know what a mesh is and it's not been exlpained properly
Each of us contributed equally in the completion of this exercise:
Enrico Benedettini: 0.33
Anders Rolighed Larsen: 0.33
Clèment: 0.33
